from django.shortcuts import render, redirect 
from .models import User

# Create your views here.
def index(request):

    context = {
        "all_the_users": User.objects.all()
    }
    return render(request, 'index.html', context)

def add_user(request):
    if request.method == "POST":
    # User.objects.create(first_name = request.session['fname'], last_name = request.session['lname'], email_address = request.session['email'], age = request.session['age'])

        last_user = User.objects.create(first_name = request.POST['fname'], last_name = request.POST['lname'], email_address = request.POST['email'], age = request.POST['age'])
        last_user.save()

    print(last_user)
    return redirect('/')