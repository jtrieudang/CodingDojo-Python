from django.shortcuts import render, HttpResponse
from .models import Book, Author


def index(request):
    return HttpResponse("this is the equivalent of @app.route('/')!")
