from django.shortcuts import render, redirect
from django.contrib import messages

from .models import Show
# Create your views here.

def index(request):
    context={
        "shows": Show.objects.all()
    }
    return render(request,'readall.html',context)

def showsummary(request, show_id):
    context={
        "show": Show.objects.get(id=show_id)
    }
    return render(request, 'readone.html',context)

def edit(request, show_id):
    show = Show.objects.get(id=show_id)
    show.release_date = show.release_date.strftime("%Y-%m-%d")
    context={
        "show": show
    }
    return render(request, "editshow.html", context)


def update_show(request, show_id):
    errors = Show.objects.basic_validator(request.POST)
# look for INDENTATION
    if len(errors) > 0: 
        for key, err in errors.items():
            messages.error(request, err)

        return redirect(f"/shows/{show_id}/edit")
# return redirect(request.META.get('HTTP_REFERER')) OR THIS COULD WORK TOO
# problem solved by changing {show.id} to {show_id}
    show = Show.objects.get(id=show_id)

    show.title = request.POST["title"]
    show.network = request.POST["network"]
    show.release_date = request.POST["rdate"]
    show.description = request.POST["description"]

    show.save()

    return redirect(request.META.get('HTTP_REFERER'))

def create(request):
    context={
        "shows": Show.objects.all()
    }
    return render(request,'create.html',context)


def create_hit(request):
    errors = Show.objects.basic_validator(request.POST)
    if len(errors) > 0: 
        for key, err in errors.items():
            messages.error(request, err)

        return redirect("/shows/new")

    show = Show.objects.create(
    title = request.POST["title"], 
    network = request.POST["network"],
    release_date = request.POST["rdate"],
    description = request.POST["description"])

    return redirect(f"/shows/{show.id}")
    # this basically takes me to shows/(newestid that was created)

def deletes(request, show_id):
    show = Show.objects.get(id=show_id)
    show.delete()

    return redirect("/shows")
