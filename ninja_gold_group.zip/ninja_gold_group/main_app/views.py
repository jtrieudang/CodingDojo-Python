from django.shortcuts import render, HttpResponse, redirect
from datetime import datetime
import random

def index(request):
    if 'your_gold' not in request.session:
        request.session['your_gold'] = 0
        request.session['activities']=[]
    context ={
        'your_gold': request.session['your_gold'],
       
        'activities': request.session['activities']
    }
    return render(request, "ninja_gold_index.html", context)
    
def process_farm(request):
    #request.session['your_gold'] = request.POST['gold']
    activities = request.session['activities']
    timestamp = datetime.now()
    # activities.append({
    #     'gold': request.POST['gold'],
    #     'timestamp': timestamp.strftime('%c')
    # })
    request.session['activities'] = activities
    gold = request.session['your_gold']
    chance = (random.randint(10,20))
    gold=gold+chance
    HttpResponse(f"Entered a farm and gained {chance} gold")
    request.session['your_gold'] = gold
    activities.append({
        'gold': gold,
        'timestamp': timestamp.strftime('%c')
    })
    return(redirect('/'))

def process_cave(request, gold):
    #request.session['your_gold'] = request.POST['gold']
    activities = request.session['activities']
    gold = request.session['your_gold']
    timestamp = datetime.now()
    # activities.append({
    #     'gold': request.POST['gold'],
    #     'timestamp': timestamp.strftime('%c')
    # })
    request.session['activities'] = activities

    chance = (random.randint(5,10))
    gold=gold+chance
    HttpResponse(f"Entered a cave and gained {chance} gold")
    request.session['your_gold'] = gold
    activities.append({
        'gold': gold,
        'timestamp': timestamp.strftime('%c')
    })
    return(redirect('/'))


def process_house(request, gold):
    #request.session['your_gold'] = request.POST['gold']
    activities = request.session['activities']
    gold = request.session['your_gold']
    timestamp = datetime.now()
    # activities.append({
    #     'gold': request.POST['gold'],
    #     'timestamp': timestamp.strftime('%c')
    # })
    request.session['activities'] = activities

    chance = (random.randint(2,5))
    gold=gold+chance
    HttpResponse(f"Entered a house and gained {chance} gold")
    request.session['your_gold'] = gold
    activities.append({
        'gold': gold,
        'timestamp': timestamp.strftime('%c')
    })
    return(redirect('/'))


def process_casino(request, gold):
    #request.session['your_gold'] = request.POST['gold']
    activities = request.session['activities']
    gold = request.session['your_gold']
    timestamp = datetime.now()
    # activities.append({
    #     'gold': request.POST['gold'],
    #     'timestamp': timestamp.strftime('%c')
    # })
    request.session['activities'] = activities
    request.session['your_gold'] = gold
    chance = (random.randint(-50,50))
    gold=gold+chance
    HttpResponse(f"Entered a casino and gained {chance} gold")
    activities.append({
        'gold': gold,
        'timestamp': timestamp.strftime('%c')
    })
    return(redirect('/'))


