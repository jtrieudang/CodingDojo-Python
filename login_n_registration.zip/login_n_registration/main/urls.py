from django.urls import path

from . import views

urlpatterns = [
    path('', views.show_login_reg_page),
    path('users', views.register_user),
    path('login', views.login_user),
    path('success', views.success_page),
    path("logout", views.logout),
    path("wall", views.wall_page),
    path('add_message', views.add_message)
    #creating a url pathway to actually call the add_message function from views
]