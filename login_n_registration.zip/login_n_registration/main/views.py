from django.shortcuts import render, redirect

from django.contrib import messages
import bcrypt

from .models import User, Message, Comments

def show_login_reg_page(request):
    return render(request, "login-reg.html")

def register_user(request):
    errors = User.objects.basic_validator(request.POST)

    if len(errors) > 0:
        for key, err in errors.items():
            messages.error(request, err)
        return redirect("/")

    hashed_pw = bcrypt.hashpw(request.POST["password"].encode(), bcrypt.gensalt()).decode()

    created_user = User.objects.create(
        first_name=request.POST["first_name"],
        last_name=request.POST["last_name"],
        email=request.POST["email"],
        password=hashed_pw
    )

    request.session["user_id"] = created_user.id

    return redirect("/success")



def login_user(request):
    potential_users = User.objects.filter(email=request.POST['email'])

    if len(potential_users) == 0:
        messages.error(request, "Please check your email and password.")

        return redirect('/')

    user = potential_users[0]

    if not bcrypt.checkpw(request.POST['password'].encode(), user.password.encode()):
        messages.error(request, "Please check your email or password.")

        return redirect('/')

    request.session["user_id"] = user.id
    return redirect('/success')


def success_page(request):
    if "user_id" not in request.session:
        messages.error(request, "You must log in to view this page!")
        return redirect('/success')

    context = {
        "user": User.objects.get(id=request.session["user_id"])
    }
    # (1) call out single alone
    return render(request, "success.html", context)

def logout(request):
    request.session.pop("user_id")
    
    return redirect("/")



def wall_page(request):
    if "user_id" not in request.session:
        messages.error(request, "You must log in to view this page!")
        return redirect('/')

    context = {
        "user": User.objects.get(id=request.session["user_id"]),
        "messages": Message.objects.all()
    }
    return render(request, "wall.html", context)

def add_message(request):
    Message.objects.create(
        message=request.POST["message"],
        #created_at=request.POST['create_at'],
        #created_at is done automatically, we can access it whenever, we dont need to assign it
        owner=User.objects.get(id=request.session['user_id'])
    )
    #this is fine
    return redirect("/wall")
