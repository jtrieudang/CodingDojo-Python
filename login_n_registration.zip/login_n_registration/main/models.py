from django.db import models
import re

class UserManager(models.Manager):
    def basic_validator(self, data):
        errors={}

        EMAIL_REGEX = re.compile(r'^[a-zA-Z0-9.+_-]+@[a-zA-Z0-9._-]+\.[a-zA-Z]+$')

        if len(data['first_name']) <2: 
            errors['first_name'] = "Please enter first name at least 2 characters."

        if len(data['last_name']) <2: 
            errors['last_name'] = "Please enter last name at least 2 characters."

        if len(data['email']) <3: 
            errors['email'] = "Please enter first name at least 3 characters."

        elif not EMAIL_REGEX.match(data['email']): 
            errors['email'] = "Please eneter a valid email address!"

        if len(data['password']) <8: 
            errors['password'] = "Please enter first name at least 8 characters."

        if data["pw_confirm"] != data["password"]:
            errors["pw_confirm"] = "Please match your password."

        return errors

class User(models.Model):
    first_name= models.CharField(max_length=100)
    last_name= models.CharField(max_length=100)
    email= models.CharField(max_length=100)
    password= models.CharField(max_length=64)

    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)

    objects = UserManager()

class Message(models.Model):
    message= models.TextField(max_length=255)
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)

    owner = models.ForeignKey(User, related_name='user_messages', on_delete=models.CASCADE)

class Comments(models.Model):
    comment= models.TextField(max_length=255)
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)

    owner = models.ForeignKey(User, related_name='user_comments', on_delete=models.CASCADE)
    message_comments = models.ForeignKey(Message, related_name='message_comments', on_delete=models.CASCADE)
