from django.apps import AppConfig


class MyProjectAppConfig(AppConfig):
    name = 'my_project_app'
