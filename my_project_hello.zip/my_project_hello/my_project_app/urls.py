from django.urls import path

from . import views

urlpatterns = [
    path('', views.index),
    path('new/',views.new),# this to perform on localhost:8000/new <- different page
    path('create/',views.create),
    path('<int:my_num>',views.show),
    path('<int:my_num>/edit',views.edit),
    path('<int:my_num>/delete',views.destory),
]
