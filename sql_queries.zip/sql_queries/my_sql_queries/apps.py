from django.apps import AppConfig


class MySqlQueriesConfig(AppConfig):
    name = 'my_sql_queries'
