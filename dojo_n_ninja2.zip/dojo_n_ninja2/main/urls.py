from django.urls import path, include
from . import views

urlpatterns = [
    path('', views.index),
    path("dojos",views.show_new_dojo_page),
    path("dojos/create",views.add_new_dojo),
    path('dojos/<int:dojo_id>', views.show_dojo_page),
    path('dojos/<int:dojo_id>/ninjas/create',views.create_ninja)
    
]