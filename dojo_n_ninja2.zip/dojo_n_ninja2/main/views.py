from django.shortcuts import render, redirect
from django.views.generic import TemplateView, ListView
from .models import Ninja, Dojo

def index(request):
    context = {
        'dojos' : Dojo.objects.all()
        }
    return render(request, "index.html", context)

def add_new_dojo(request):
    Dojo.objects.create(
        name=request.POST.get('name'),
        city=request.POST.get('city'),
        state=request.POST.get('state')
    )

    return redirect('/dojos')

def show_new_dojo_page(request):
    return render(request, 'new-dojo.html')

def show_dojo_page(request, dojo_id):
    context= {
        'dojo' : Dojo.objects.get(id=dojo_id)
    }

    return render(request, 'show-dojo.html', context)

def new_dojo_page(request):
    return render(request, 'new-dojo.html')

def delete_dojo(request, dojo_id):
    dojo=Dojo.objects.get(id=dojo_id)
    dojo.delete()

    return redirect('/dojos')


def create_ninja(request, dojo_id):
    Ninja.objects.create(
    dojo = Dojo.objects.get(id=dojo_id),
    first_name=request.POST.get('ninja_first_name'),
    last_name=request.POST.get('ninja_last_name'),

    )

    return redirect('/dojos')

