from django.urls import path
from .import views
from .models import Show

urlpatterns=[
    path('shows', views.index),
    path('shows/<int:show_id>', views.showsummary),
    path('shows/<int:show_id>/edit', views.edit),
    path('shows/<int:show_id>/update', views.update_show), #button update takes us here
    path('shows/new', views.create), #just the page of the create new
    path('shows/create', views.create_hit), #once we hit create new show
    path('shows/<int:show_id>/destroy', views.deletes),

]
# from django.urls import path
# from . import views	

# urlpatterns = [
#     path('shows', views.shows),
#     path('shows/new', views.add_show),
#     path('shows/<int:show_id>/edit', views.edit_show),
#     path('shows/<int:show_id>', views.tv_show)

# ]