from django.shortcuts import render, redirect
from .models import Show
# Create your views here.

def index(request):
    context={
        "shows": Show.objects.all()
    }
    return render(request,'readall.html',context)

def showsummary(request, show_id):
    context={
        "show": Show.objects.get(id=show_id)
    }
    return render(request, 'readone.html',context)

def edit(request, show_id):
    show = Show.objects.get(id=show_id)
    show.release_date = show.release_date.strftime("%Y-%m-%d")
    # show.title = show.title.get(request.post["title"])
    # show.network = show.network.get(request.post["nwork"])
    # show.release_date = show.release_date.get(request.post["rdate"])
    # show.description = show.description.get(request.post["rdate"])
    context={
        "show": show
    }
    return render(request, "editshow.html", context)


def update_show(request, show_id):
    show = Show.objects.get(id=show_id)

    show.title = request.POST["title"]
    show.network = request.POST["nwork"]
    show.release_date = request.POST["rdate"]
    show.description = request.POST["desc"]

    show.save()

    return redirect(request.META.get('HTTP_REFERER'))

def create(request):
    context={
        "shows": Show.objects.all()
    }
    return render(request,'create.html',context)

def create_hit(request):
    show = Show.objects.create(
    title = request.POST["title"], 
    network = request.POST["nwork"],
    release_date = request.POST["rdate"],
    description = request.POST["desc"])

    return redirect(f"/shows/{show.id}")
    # this basically takes me to shows/(newestid that was created)

def deletes(request, show_id):
    show = Show.objects.get(id=show_id)
    show.delete()

    return redirect("/shows")


# from django.shortcuts import render
# from .models import Show

# def shows(request):
#     context = {
#         'shows' : Show.objects.get(id=show_id)
#     }
#     return render(request, 'all-shows.html', context)


# def add_show_show(request):
#     Show.objects.create(
#         title=request.POST.get('title'),
#         network=request.POST.get('network'),
#         release_date=request.POST.get('release_date'),
#         description = request.POST.get('description'),
#     )
#     return redirect('/shows')


# def add_show(request):
#     return render(request, 'add-a-new-show.html')


# def edit_show(request, show_id):
#     return render(request, 'edit-show.html')


# def tv_show(request, show_id):
#     return render(request, 'tv-show.html')
