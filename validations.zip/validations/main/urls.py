from django.urls import path

from . import views

urlpatterns = [
    path('shoes',views.all_shoe_page),
    path('shoes/create', views.add_shoe),
    path('shoes/<int:shoe_id>/edit', views.edit_shoe_page),
    path('shoes/update', views.update_shoe),
    # (3)
    path('', views.show_login_reg_page),
    path("users", views.register_user),
    # make sure to import user in VIEW
    path("login", views.login_user),
    path("logout", views.logout),
    path("shoes/<int:shoe_id>/delete", views.delete_shoe),
    # for the view page html
    path("shoes/<int:shoe_id>", views.view_shoe_page)
]


# Note: this is an overview of:
# HIDDEN FIELD(1) edit-shoes.html
# ERRORS/VALIDATION (2) in models
# SECURITY/LOGIN (3)
# LOGIN(4)
# PROTECTING PAGE (5)
# LOGOUT (6)
# 1 to many relation (7) in models.

# Extra, release_date and for validation (8)