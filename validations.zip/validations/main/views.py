from django.shortcuts import render, redirect
from django.contrib import messages
import bcrypt

from .models import Shoe, User

def all_shoe_page(request):
    # (5) protection if no logged in 
    if "user_id" not in request.session:
        messages.error(request, "You must log in to view this page!")
        return redirect('/')
        # (5) end of it, that's it, line 10 if you're not log in.

    context = {
        "shoes": Shoe.objects.all(),
        "user": User.objects.get(id=request.session['user_id'])
    }
    return render(request, "all-shoe.html", context)


# this is from the form for post V V V and show errors
def add_shoe(request):
    errors = Shoe.objects.basic_validator(request.POST)
# look for INDENTATION
    if len(errors) > 0: 
        for key, err in errors.items():
            messages.error(request, err)

        return redirect("/shoes")
# for adding^ errors

# can have variable as
# created_shoe = Shoe.objects.create(      <--- but you would need to change line 34 to return redirect(f"/shoes/{created_shoe.id}") 
    Shoe.objects.create(
        brand=request.POST["brand"],
        series=request.POST["series"],
        color=request.POST["color"],
        size=request.POST["size"],
        owner=User.objects.get(id=request.session['user_id'])
        #(7) add owner!!! this is from model as well.
    )

    return redirect("/shoes")

def edit_shoe_page(request, shoe_id):
# (5) protection if no logged in 
    if "user_id" not in request.session:
        messages.error(request, "You must log in to view this page!")
        return redirect('/')
        # (5) end of it, that's it, line 10 if you're not log in.

    # if you didn't create the shoe.
    shoe = Shoe.objects.get(id = shoe_id)

    if request.session['user_id'] != shoe.owner.id:
        messages.error(request,"You didn't create that!")
        return redirect("/shoes")

# (8) RELEASE DATE to show the default date
    shoe.release_date = shoe.release_date.strftime("%Y-%m-%d")

    context = {
        "shoe": shoe
        # this becomes short because we made it into a variable on line 53
    }
    return render(request, "edit-shoes.html", context)

def update_shoe(request):
    shoe = Shoe.objects.get(id=request.POST["shoe_id"])

    shoe.brand = request.POST["brand"]
    shoe.series = request.POST["series"]
    shoe.color = request.POST["color"]
    shoe.size = request.POST["size"]
# hidden value + save it
    shoe.save()
    return redirect("/shoes")

# (3)

def show_login_reg_page(request):
    return render(request, "login-reg.html")

# register the user V V
def register_user(request):
    # adding validation
    errors = User.objects.basic_validator(request.POST)

    if len(errors) > 0:
        for key, err in errors.items():
            messages.error(request, err)
        return redirect("/")
        # remember to loop thru html page line 10-13 IN... login-reg.html

# hash/cover the password
    # hashedpw = bycrpt.hashpw('test'.encode(), bcrypt.gensalt()).decode() <--- orginial was test... but we want to put in password with POST instead
    hashed_pw = bcrypt.hashpw(request.POST["password"].encode(), bcrypt.gensalt()).decode()
    # ^^^ can be a different variable name (hashedpw)     ^^^make sure to import bycrpt

    created_user = User.objects.create(
        first_name=request.POST["first_name"],
        last_name=request.POST["last_name"],
        email=request.POST["email"],
        password=hashed_pw
    )
        # password=request.POST["password"] <----orgininal 
# keep in mind we dont want to save() because we want to validate the password
   
#    this in effect logs in the new uer/ dont have to relog every time
    request.session["user_id"] = created_user.id
        # whole created_user is to save it when we made it variable on line 97
# you can find the password in the sqlite explorer
    return redirect("/shoes")

# # create login (4)
def login_user(request):
    potential_users = User.objects.filter(email=request.POST['email'])

# this V means there's no user
    if len(potential_users) == 0:
        messages.error(request, "Please check your email and password.")

        return redirect('/')

    user = potential_users[0]

# check if password and email is match and correct
    if not bcrypt.checkpw(request.POST['password'].encode(), user.password.encode()):
        # if not bcrypt.checkpw(request.POST['password'].encode(), potential_users[0].password.enode()): <-- orginal, made it into a variable on line 122
        messages.error(request, "Please check your email and password.")

        return redirect('/')

# if match...
    request.session["user_id"] = user.id
    # request.session["user_id"] = potential_users[0] <-- orginal, made it into a variable on line 122
    return redirect('/shoes')

# (6)
def logout(request):
    request.session.pop("user_id")
# this would remove everything from the session
    # request.session.clear()
    
    return redirect("/")
# make a url in urls.py

# (7)
def delete_shoe(request, shoe_id):
    shoe_to_delete = Shoe.objects.get(id=shoe_id)

 # if you didn't create the shoe.
# have it shoe to delete because we didn't include the variable from line 66
    if request.session['user_id'] != shoe_to_delete.owner.id:
        messages.error(request,"You can't delete you didn't create!")
        return redirect("/shoes")

    shoe_to_delete.delete()

    return redirect("/shoes")

# function to see what user own only
def view_shoe_page(request, shoe_id):
    context = {
        "shoe": Shoe.objects.get(id=shoe_id),
        "user": User.objects.get(id=request.session["user_id"])
    }

    return render(request, "view-shoe.html", context)