from django.db import models
import re
from datetime import datetime

class UserManager(models.Manager):
    def basic_validator(self, data):
        errors = {}
 #    email confirmation V V V ALSO import at the top import er !!!!!
        EMAIL_REGEX = re.compile(r'^[a-zA-Z0-9.+_-]+@[a-zA-Z0-9._-]+\.[a-zA-Z]+$')

        if len(data["first_name"]) < 1:
            errors["first_name"] = "Please enter at least 1 character for your first name!"
        
        if len(data["last_name"]) < 2:
            errors["last_name"] = "Please enter at least 2 character for your last name!"
        
        if len(data["email"]) < 1:
            errors["email"] = "Please enter at least 1 character for your email!"
 #    email confirmation V V V test whether a field matches the patter
        elif not EMAIL_REGEX.match(data['email']): 
            errors['email'] = "Please eneter a valid email address!"

        if len(data["password"]) < 8:
            errors["password"] = "Please enter at least 8 character for your password!"

        if data["pw_confirm"] != data["password"]:
            errors["pw_confirm"] = "Please match your password."

        return errors
        # remember to RETURN! and add 'objects' under the original class.. in this case is class User line 68
# (3a)^now we create  validation for paassword
# (3)
class User(models.Model):
    first_name= models.CharField(max_length=100)
    last_name= models.CharField(max_length=100)
    email= models.CharField(max_length=100)
    password= models.CharField(max_length=64)

    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)

# makemigrations then migrate since starting out fresh again 

    objects = UserManager()


# here shows errors and make sure to return!
class ShoeManager(models.Manager):
    def basic_validator(self, post_data):
        errors = {}

        if len(post_data["brand"]) < 2:
            errors["brand"] = "Please enter a brand at least 2 characters."
        if len(post_data["series"]) < 4:
            errors["series"] = "Please enter a series at least 4 characters."
        if len(post_data["color"]) < 3:
            errors["color"] = "Please enter a color at least 3 characters."
        if len(post_data["size"]) < 1:
            errors["size"] = "Please enter a size at least 2 characters."
# smallest size V V V 
        elif float(post_data['size']) < 4:
            errors["size"] = "Please enter at least size greater than 4."
# (8) for release date for future
        if len(post_data["release_date"]) < 1:
            errors["release_date"] = "Please enter a release date!"
# import datetime at the top
        elif datetime.strptime(post_data["release_date"], "%Y-%m-%d") > datetime.now():
            errors["release_date"] = "Please enter a release date not in the future!"


        return errors

class Shoe(models.Model):
    brand = models.CharField(max_length=64)
    color = models.CharField(max_length=15)
    series = models.CharField(max_length=20)
    size = models.FloatField()
    release_date= models.DateField(default="2020-04-20")
# (8) validation for release dates -> make if make changes on models.Model
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)

# (7)allow to reference shivanni.shoes.ownedall() to get all of shivanni's shoes 
# when we delete a user, this deletes all the shoes associated with that user
    owner = models.ForeignKey(User, related_name='shoes_owned', on_delete=models.CASCADE)
# (7) you need to move this to the bottom because you need 'User' on top because you're referencing the class.

    objects = ShoeManager()


