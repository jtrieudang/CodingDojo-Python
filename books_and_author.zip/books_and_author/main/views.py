from django.shortcuts import render, redirect
from .models import Book, Author
# Create your views here.
def index(request):
    context = {
        'books' : Book.objects.all()
    }
    return render(request, 'index.html', context)

def add_book(request):
    Book.objects.create(
        title=request.POST.get('title'),
        description = request.POST.get('description')
    )

    return redirect('/')

def show_book_page(request, book_id):
    context ={
        'book' : Book.objects.get(id=book_id),
        'Authors' : Author.objects.all()
    }
    return render(request, 'books.html', context)

def add_author_to_book(request):
    author = Author.objects.get(id=request.POST.get('author_id'))
    book = Book.objects.get(id=request.POST.get('book_id'))
    author.books.add(book)

    return redirect(request.META.get('HTTP_REFERER'))

def show_add_author_page(request):
    context = {
        'authors' : Author.objects.all(),
        'books': Book.objects.all()
    }
    return render(request, 'add-an-author.html', context)


def add_author(request):
    Author.objects.create(
        first_name=request.POST.get('first_name'),
        last_name=request.POST.get('last_name'),
        notes=request.POST.get('notes'),
    )
    return redirect('/authors')


def show_author_page(request, author_id):
    context={
        'author' : Author.objects.get(id=author_id),
        'books' : Book.objects.all()
    }
    return render(request, 'authors.html', context)