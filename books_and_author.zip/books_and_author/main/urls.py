from django.urls import path
from . import views	# the . indicates that the views file can be found in the same directory as this file
                    
urlpatterns = [
    path('', views.index),
    path('books/create', views.add_book),
    path('books/<int:book_id>', views.show_book_page),
    path('authors', views.show_add_author_page),
    path('books/add_author_to_book', views.add_author_to_book),
    # path('authors/create', views.add_author),
    path('authors/<int:author_id>', views.show_author_page),
    path('authors/add', views.add_author_to_book)
    

]