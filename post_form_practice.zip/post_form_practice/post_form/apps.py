from django.apps import AppConfig


class PostFormConfig(AppConfig):
    name = 'post_form'
