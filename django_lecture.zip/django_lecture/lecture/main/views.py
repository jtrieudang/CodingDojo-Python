from django.shortcuts import render, redirect

from .models import User, Album

def show_users_page(request):
    context = {
        "users": User.objects.all()
    }
# shows in the html line 13-26
    return render(request, "users.html",context)

# make a page to add new users
def new_user_page(request):
    return render(request, "new-user.html")
# you need to make it submit for http://localhost:8000/users/new because it wont send

# need to POST to pass it in
def add_new_user(request):
    User.objects.create(
        first_name= request.POST["first_name"],
        last_name= request.POST["last_name"],
        email= request.POST["email"],
        motto=request.POST["motto"]
    )
    return redirect("/users")
    # we dont render because it will send it twice, and make sure to add redirect to the top
    # create a path to redirect for create

def delete_user(request, user_id):
    user = User.objects.get(id=user_id)
    user.delete()

    return redirect("/users")

def show_user_page(request, user_id):
    context = {
        "user": User.objects.get(id=user_id)
    }
    return render(request, "show-user.html", context)

# redirect back to user
def delete_album(request, album_id, user_id):
    album = Album.objects.get(id=album_id)
    album.delete()

    return redirect(f"/users/{user_id}")

def create_album(request, user_id):
    Album.objects.create(
        owner=User.objects.get(id=user_id),
        title=request.POST["title"],
        artist=request.POST["artist"],
        release_date=request.POST["release_date"]
    )

    return redirect(f"/users/{user_id}")

    def logout(request):
    request.session.pop("user_id")
    
    return redirect("/")