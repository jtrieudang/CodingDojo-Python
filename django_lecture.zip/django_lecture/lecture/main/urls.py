from django.urls import path

from . import views

urlpatterns = [
    path("users", views.show_users_page),
    # new route for new-user.html
    path("users/new", views.new_user_page),
    path("users/create", views.add_new_user),
    # this top url is from form
    path("users/<int:user_id>/delete", views.delete_user),
    # this link top is from the user id in line 29
    path("users/<int:user_id>", views.show_user_page),
    path("users/<int:user_id>/albums/<int:album_id>/delete", views.delete_album),
    path("users/<int:user_id>/albums/create", views.create_album),
]