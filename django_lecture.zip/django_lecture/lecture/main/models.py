from django.db import models

class User(models.Model):
    first_name=models.CharField(max_length=64)
    last_name=models.CharField(max_length=64)
    # username=models.CharField(min_length=8)
    email=models.EmailField()
    motto=models.TextField()
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)

class Album(models.Model):
    title=models.CharField(max_length=64)
    artist=models.CharField(max_length=64)
    release_date=models.DateTimeField(default ="2020-04-14")
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)
# one to many
    owner = models.ForeignKey(User, on_delete=models.CASCADE, related_name="albums") 
