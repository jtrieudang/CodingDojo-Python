from django.shortcuts import render, HttpResponse, redirect
from django.contrib import messages
from main.models import *
import bcrypt

def index(request):
    if "user_id" in request.session:
        return redirect('/books')

    return render(request,'index.html')


def register(request):
    errors = User.objects.validator(request.POST)
    if len(errors)>0:
        for key, val in errors.items():
            messages.error(request, val)
        return redirect('/')

    pw = request.POST['password']
    pw_hash = bcrypt.hashpw(pw.encode(), bcrypt.gensalt()).decode()

    new_user = User.objects.create(
        first_name = request.POST['first_name'],
        last_name = request.POST['last_name'],
        email = request.POST['email'],
        password = pw_hash,
        birthday = request.POST['birthday']
    )

    request.session['user_id'] = new_user.id

    return redirect('/books')


def login(request):

    user = User.objects.filter(email=request.POST['email'])
    if user:
        logged_user = user[0]
        if bcrypt.checkpw(request.POST['password'].encode(), logged_user.password.encode()):
            request.session['user_id'] = logged_user.id
            return redirect('/books')
        
        messages.error(request, "That password does not match that email.")
        return redirect('/')

    messages.error(request, "That email is not registered.")
    return redirect('/')


def books_page(request):
    if "user_id" not in request.session:
        messages.error(request, "You must be logged in to view that page.")
        return redirect('/')
    
    reviews_reversed = Review.objects.all().order_by('-created_at')

    context = {
        'user': User.objects.get(id = request.session['user_id']),
        'review1': reviews_reversed[0],
        'review2': reviews_reversed[1],
        'review3': reviews_reversed[2],
        'books': Book.objects.all(),
    }

    return render(request, 'books.html', context)


def logout(request):
    request.session.pop("user_id")

    return redirect('/')


def add_book_page(request):
    
    if "user_id" not in request.session:
        messages.error(request, "You must be logged in to view that page.")
        return redirect('/')
    context = {
        'authors': Author.objects.all()
    }
    return render(request, 'add-books.html', context)


def add_book(request):
    errors = Review.objects.validator(request.POST)
    if len(errors)>0:
        for key, val in errors.items():
            messages.error(request, val)
        return redirect('/books/add')
    
    if request.POST['author'] == "empty":
        author = Author.objects.create(name = request.POST['new_author'])
    else:
        author = Author.objects.get(name = request.POST['author'])
    
    if Book.objects.filter(title = request.POST['title']):
        book = Book.objects.get(title = request.POST['title'])
    else:
        book = Book.objects.create(title = request.POST['title'], author = author)
    
    review = Review.objects.create(
        text = request.POST['text'],
        rating = request.POST['rating'],
        user = User.objects.get(id=request.session['user_id']),
        book = book,
    )
# 1
    return redirect (f'books/{book.id}')


def book_profile(request, book_id):
    if "user_id" not in request.session:
        messages.error(request, "You must be logged in to view that page.")
        return redirect('/')

    context = {
        'book': Book.objects.get(id=book_id),
        'user': User.objects.get(id=request.session['user_id'])
    }

    return render(request, 'book-profile.html', context)


def delete_review(request, review_id):
    review = Review.objects.get(id=review_id)
    book = review.book
    review.delete()
    return redirect (f'/books/{book.id}')


def add_review(request):
    book = Book.objects.get(id = request.POST['book_id'])
    
    errors = Book.objects.validator(request.POST)
    if len(errors)>0:
        for key, val in errors.items():
            messages.error(request, val)
        return redirect (f'books/{book.id}')
        
    
    Review.objects.create(
        text = request.POST['text'],
        rating = request.POST['rating'],
        user = User.objects.get(id=request.session['user_id']),
        book = book,
    )

    return redirect (f'books/{book.id}')


def user_profile(request, user_id):
    if "user_id" not in request.session:
        messages.error(request, "You must be logged in to view that page.")
        return redirect('/')

    context = {
        'user': User.objects.get(id=user_id),
    }

    return render(request, 'user-reviews.html', context)