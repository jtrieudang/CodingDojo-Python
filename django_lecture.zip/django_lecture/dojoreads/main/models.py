from django.db import models
from datetime import datetime, timedelta
import re

class UserManager(models.Manager):
    def validator(self, postData):
        errors = {}
        if len(postData['first_name'])<2:
            errors['first_name'] = "First Name must be at least 2 characters."
        elif str.isalpha(postData['first_name'])==False:
            errors['first_name'] = "First Name must only contain letters."
        if len(postData['last_name'])<2:
            errors['last_name'] = "Last Name must be at least 2 characters."
        elif str.isalpha(postData['last_name'])==False:
            errors['last_name'] = "Last Name must only contain letters."
        EMAIL_REGEX = re.compile(r'^[a-zA-Z0-9.+_-]+@[a-zA-Z0-9._-]+\.[a-zA-Z]+$')
        if not EMAIL_REGEX.match(postData['email']):
            errors['email'] = "Invalid email address."
        elif User.objects.filter(email=postData['email']):
            errors['email'] = "That email is already registered."
        if len(postData['password'])<8:
            errors['password'] = "Password must be at least 8 characters."
        elif postData['password'] != postData['pw_confirm']:
            errors['password'] = "Password does not match confirmation."
        if postData['birthday']=='':
            errors['birthday'] = "Birthday field is empty."
        birthday = datetime.strptime(postData['birthday'], '%Y-%m-%d')
        if birthday>datetime.today() - timedelta(days=13*365.24):
            errors['birthday'] = "You must be at least 13 years old to register."
        return errors

class BookManager(models.Manager):
    def validator(self, postData):
        errors = {}
        if len(postData['title'])==0:
            errors['title'] = "Title field is empty."
        if len(postData['new_author'])==0 and postData['author']=='empty':
            errors['author'] = "Author field is empty"
        if str.isalpha(postData['new_author'])==False:
            errors['new_author'] = "Author name must only contain letters."
        if len(postData['text'])<8:
            errors['text'] = "Review must be at least 8 characters"
        return errors

class AddReviewManager(models.Manager):
    def validator(self, postData):
        errors = {}
        if len(postData['text'])<8:
            errors['text'] = "Review must be at least 8 characters"
        return errors

class User(models.Model):
    first_name = models.CharField(max_length = 45)
    last_name = models.CharField(max_length = 45)
    email = models.EmailField(max_length = 254)
    password = models.CharField(max_length = 60)
    birthday = models.DateField()
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)

    objects = UserManager()

class Author(models.Model):
    name = models.CharField(max_length = 64)
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)

    objects = BookManager()

class Book(models.Model):
    title= models.CharField(max_length=200)
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)
    author = models.ForeignKey(Author, related_name = "books", on_delete = models.CASCADE) 
    
    objects = AddReviewManager()

class Review(models.Model):
    text = models.TextField()
    rating  = models.IntegerField()
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)
    user = models.ForeignKey(User, related_name = "reviews", on_delete = models.CASCADE) 
    book = models.ForeignKey(Book, related_name = "reviews", on_delete = models.CASCADE)

    objects = BookManager()