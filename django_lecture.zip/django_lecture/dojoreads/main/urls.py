from django.urls import path
from main import views

urlpatterns = [
    path('', views.index),
    path('register', views.register),
    path('login', views.login),
    path('books', views.books_page),
    path('logout', views.logout),
    path('books/add', views.add_book_page),
    path('add_book', views.add_book),
    # 1
    path('books/<int:book_id>', views.book_profile),
    path('<int:review_id>/delete', views.delete_review),
    path('add_review', views.add_review),
    path('user/<int:user_id>', views.user_profile),
]
 