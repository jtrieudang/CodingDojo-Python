from django.shortcuts import render, redirect
from django.contrib import messages
import bcrypt

from .models import *


def login_pg(request):
    return render(request, "login.html")


def register(request):
    errors = User.objects.validator(request.POST)
    if len(errors)>0:
        for key, val in errors.items():
            messages.error(request, val)
        return redirect('/')
    
    pw = request.POST['password']

    pw_hash = bcrypt.hashpw(pw.encode(), bcrypt.gensalt()).decode()

    create_new_user = User.objects.create(
        first_name = request.POST['first_name'],
        last_name = request.POST['last_name'],
        email = request.POST['email'],
        password = pw_hash,
    )

    request.session['user_id'] = create_new_user.id
    return redirect('/dashboard')


def dashboard(request):
    if "user_id" not in request.session:
        messages.error(request, "Must be login to view.")
        return redirect('/')

    trip = Trip.objects.all().order_by('-created_at')

    context = {
        "user": User.objects.get(id=request.session['user_id']),
        "trip": trip,
    }
    return render(request, "dashboard.html", context)


def user_login(request):
    current_users = User.objects.filter(email=request.POST['email'])

    if len(current_users) == 0:
        messages.error(request, "Please check your email and password.")
        return redirect('/')

    user = current_users[0]

    if not bcrypt.checkpw(request.POST['password'].encode(), user.password.encode()):
        messages.error(request, "Please check your password.")
        return redirect('/')

    request.session["user_id"] = user.id
    return redirect('/dashboard')


def logout(request):
    request.session.pop("user_id")
    return redirect('/')


def new_trip_pg(request):
    if "user_id" not in request.session:
        messages.error(request, "Must be login to view.")
        return redirect('/')

    context = {
        "user": User.objects.get(id=request.session['user_id']),
        "trip": Trip.objects.all(),
    }
    return render(request, 'new-trip.html', context)


def add_trip(request):
    errors = Trip.objects.validator(request.POST)
    if len(errors) > 0: 
        for key, err in errors.items():
            messages.error(request, err)
        return redirect('/trip/new')

    Trip.objects.create(
        destination= request.POST["destination"],
        start_date= request.POST["start_date"],
        end_date= request.POST["end_date"],
        plan= request.POST["plan"],
        user= User.objects.get(id=request.session['user_id'])
    )
    return redirect("/dashboard")


def delete(request, trip_id):
    trip = Trip.objects.get(id=trip_id)
    trip.delete()
    return redirect ('/dashboard')


def edit_trip_pg(request, trip_id):
    if "user_id" not in request.session:
            messages.error(request, "Must be login to view.")
            return redirect('/')

    context = {
        "user": User.objects.get(id=request.session["user_id"]),
        "trip": Trip.objects.get(id = trip_id),
    }
    return render(request, "edit-trip.html", context)


def update_trip(request, trip_id):
    errors= Trip.objects.validator(request.POST)
    if len(errors) >0:
        for err in errors.values():
            messages.error(request, err)
        return redirect(f"/trips/edit/{trip_id}")

    trip = Trip.objects.get(id=request.POST["trip_id"])

    trip.destination= request.POST["destination"]
    trip.start_date= request.POST["start_date"]
    trip.end_date= request.POST["end_date"]
    trip.plan= request.POST["plan"]
    trip.save()

    return redirect("/dashboard")


def about_trip(request, trip_id):
    if "user_id" not in request.session:
            messages.error(request, "Must be login to view.")
            return redirect('/')

    context = {
        'user': User.objects.get(id=request.session['user_id']),
        'trip' : Trip.objects.get(id=trip_id),
    }
    return render(request, 'trip-view.html', context)