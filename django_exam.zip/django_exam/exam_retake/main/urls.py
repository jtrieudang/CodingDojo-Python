from django.urls import path

from . import views

urlpatterns = [
    path('', views.login_pg),
    path('register', views.register),
    path('dashboard', views.dashboard),
    path('login', views.user_login),
    path('logout', views.logout),
    path('trip/new', views.new_trip_pg),
    path('add_trip', views.add_trip),
    path('trips/<int:trip_id>/delete', views.delete),
    path('trips/edit/<int:trip_id>', views.edit_trip_pg),
    path('trips/update/<int:trip_id>', views.update_trip),
    path('trips/<int:trip_id>', views.about_trip),
]