from django.db import models
import re
from datetime import datetime

class UserManager(models.Manager):
    def validator(self, data):
        errors = {}
        
        EMAIL_REGEX = re.compile(r'^[a-zA-Z0-9.+_-]+@[a-zA-Z0-9._-]+\.[a-zA-Z]+$')

        if len(data["first_name"]) < 3:
            errors["first_name"] = "Please enter more than 2 characters for your first name!"
        
        if len(data["last_name"]) < 3:
            errors["last_name"] = "Please enter more than 2 characters for your last name!"
        
        if len(data["email"]) < 3:
            errors["email"] = "Please enter more than 2 characters for your email!"

        elif not EMAIL_REGEX.match(data['email']): 
            errors['email'] = "Please enter a valid email address!"

        if len(data["password"]) < 7:
            errors["password"] = "Please enter more than 6 characters for your password!"

        if data["pw_confirm"] != data["password"]:
            errors["pw_confirm"] = "Please match your password."

        return errors

class User(models.Model):
    first_name= models.CharField(max_length = 45)
    last_name= models.CharField(max_length = 45)
    email= models.CharField(max_length = 200)
    password= models.CharField(max_length = 50)
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)

    objects = UserManager()

class TripManager(models.Manager):
    def validator(self, postdata):
        errors = {}

        if len(postdata["destination"]) < 3:
            errors["destination"] = "A trip destination must consist of at least 3 characters or more!"
        
        if len(postdata["start_date"]) < 1:
            errors["start_date"] = "A start date must be provided!"

#black belt feature
        # elif datetime.strptime(postdata["start_date"], "%Y-%m-%d") < datetime.now():
        #     errors["start_date"] = "Please enter a future date!"

        if len(postdata["end_date"]) < 1:
            errors["end_date"] = "A end date must be provided!"

        if len(postdata["plan"]) < 3:
            errors["plan"] = "A plan must be provided!"

        return errors

class Trip(models.Model):
    destination=models.CharField(max_length = 200)
    start_date= models.DateField(default="2020-04-28")
    end_date= models.DateField(default="2020-04-28")
    plan = models.CharField(max_length = 200)
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)
    user =  models.ForeignKey(User, related_name='trips', on_delete=models.CASCADE)

    objects = TripManager()
