from django.shortcuts import render, redirect
from django.contrib import messages
import bcrypt

from .models import *

# The login page
def login_page(request):
    return render(request, "login.html")

# Registration new user
def register(request):
    errors = User.objects.validator(request.POST)
    if len(errors)>0:
        for key, val in errors.items():
            messages.error(request, val)
        return redirect('/')
    
    pw = request.POST['password']

    pw_hash = bcrypt.hashpw(pw.encode(), bcrypt.gensalt()).decode()

    new_user = User.objects.create(
        first_name = request.POST['first_name'],
        last_name = request.POST['last_name'],
        email = request.POST['email'],
        password = pw_hash,
    )

    request.session['user_id'] = new_user.id

    return redirect('/dashboard')

# User login
def login_user(request):
    possible_users = User.objects.filter(email=request.POST['email'])

    if len(possible_users) == 0:
        messages.error(request, "Please check your email and password.")

        return redirect('/')

    user = possible_users[0]

    if not bcrypt.checkpw(request.POST['password'].encode(), user.password.encode()):
        messages.error(request, "Please check your password.")

        return redirect('/')

    request.session["user_id"] = user.id
    return redirect('/dashboard')

# dashboard page
def dashboard_page(request):
    if "user_id" not in request.session:
        messages.error(request, "You cannot view this page unless you are login!")
        return redirect('/')

    context = {
        "user": User.objects.get(id=request.session['user_id']),
        "job": Job.objects.all(),
    }

    return render(request, "dashboard.html", context)

# book_page
def add_job_page(request):
    if "user_id" not in request.session:
        messages.error(request, "You cannot view this page unless you are login!")
        return redirect('/')

    context = {
        "job": Job.objects.all(),
        "user": User.objects.get(id=request.session['user_id'])
    }

    return render(request, 'new_job.html', context)

def add_job(request):
    errors = Job.objects.validator(request.POST)
    if len(errors) > 0: 
        for key, err in errors.items():
            messages.error(request, err)
        return redirect('/jobs/add')

    Job.objects.create(
        title=request.POST["title"],
        description=request.POST["description"],
        location=request.POST["location"],
        user= User.objects.get(id=request.session['user_id'])
    )
    return redirect("/dashboard")

# edit job
def edit_job_page(request, job_id):
    if "user_id" not in request.session:
        messages.error(request, "You cannot view this page unless you are login!")
        return redirect('/')

    context = {
        "job": Job.objects.get(id = job_id),
        "user": User.objects.get(id=request.session["user_id"])
    }
    return render(request, "edit_job.html", context)

# update job
def job_update(request, job_id):

    errors=Job.objects.validator(request.POST)

    if len(errors) >0:
        for err in errors.values():
            messages.error(request, err)
        return redirect(f"/jobs/edit/{job_id}")

    job = Job.objects.get(id=request.POST["job_id"])

    job.brand = request.POST["title"]
    job.description = request.POST["description"]
    job.location = request.POST["location"]

    job.save()
    return redirect("/dashboard")

def delete(request, job_id):
    job = Job.objects.get(id=job_id)
    job.delete()
    return redirect ('/dashboard')


# # about the job
def job_detail(request, job_id):
    if "user_id" not in request.session:
        messages.error(request, "You cannot view this page unless you are login!")
        return redirect('/')

    context = {
        'job' : Job.objects.get(id=job_id),
        'user': User.objects.get(id=request.session['user_id'])
    }
    return render(request, 'job_detail.html', context)

# logout
def logout(request):
    request.session.pop("user_id")

    return redirect('/')

