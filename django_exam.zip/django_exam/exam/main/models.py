from django.db import models
import re

class UserManager(models.Manager):
    def validator(self, data):
        errors = {}
        
        EMAIL_REGEX = re.compile(r'^[a-zA-Z0-9.+_-]+@[a-zA-Z0-9._-]+\.[a-zA-Z]+$')

        if len(data["first_name"]) < 1:
            errors["first_name"] = "Please enter at least 1 character for your first name!"
        
        if len(data["last_name"]) < 2:
            errors["last_name"] = "Please enter at least 2 character for your last name!"
        
        if len(data["email"]) < 1:
            errors["email"] = "Please enter at least 1 character for your email!"

        elif not EMAIL_REGEX.match(data['email']): 
            errors['email'] = "Please eneter a valid email address!"

        if len(data["password"]) < 7:
            errors["password"] = "Please enter at least 7 character for your password!"

        if data["pw_confirm"] != data["password"]:
            errors["pw_confirm"] = "Please match your password."

        return errors

class User(models.Model):
    first_name = models.CharField(max_length = 45)
    last_name = models.CharField(max_length = 45)
    email = models.EmailField(max_length = 254)
    password = models.CharField(max_length = 60)
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)

    objects = UserManager()

class JobManager(models.Manager):
    def validator(self, data):
        errors = {}

        if len(data["title"]) < 2:
            errors["title"] = "Please enter at least 2 character."
        if len(data["description"]) < 2:
            errors["description"] = "Please enter at least 2 character."
        if len(data["location"]) == 0:
            errors["location"] = "Please enter a location."
        return errors

class Job(models.Model):
    title= models.CharField(max_length=200)
    description= models.CharField(max_length=200)
    location= models.CharField(max_length=200)
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)
    user =  models.ForeignKey(User, related_name='jobs', on_delete=models.CASCADE)

    objects = JobManager()