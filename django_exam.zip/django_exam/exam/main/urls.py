from django.urls import path

from . import views

urlpatterns = [
    path('', views.login_page),
    path('register', views.register),
    path('login', views.login_user),
    path('dashboard', views.dashboard_page),
    path('logout', views.logout),
    path('jobs/add', views.add_job_page),
    path('add_job', views.add_job),
    path('jobs/edit/<int:job_id>', views.edit_job_page),
    path('jobs/update/<int:job_id>', views.job_update),
    path('jobs/<int:job_id>/delete', views.delete),
    path('jobs/<int:job_id>', views.job_detail),
]