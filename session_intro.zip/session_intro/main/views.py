from django.shortcuts import render, redirect
**** SOMETHING WRONG HERE LOOK AT VIDEO vimeo.com/406377607/c14eb30c00****

from datetime import datetime


def index(request):
    if "favorite_color" not in request.session:
        request.session["favorite_color"] = "white"
        request.session['activities'] = []

    context = {
        "favorite_color": request.session["favorite_color"],
        "activities": request.session["activities"]
    }
    return render(request, "index.html", context)

def process_form(request):
    request.session['favorite_color']=request.POST["color"]
    activities = request.session['activities']

    timestamp = datetime.datetime.now()

    activities.append({
        "color":request.POST['color'],
        "timestamp": timestamp.strftime("%c")
    })

    request.session['activities']= activities
    return redirect('/')